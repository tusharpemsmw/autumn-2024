
observed = [50, 30, 20];
expected = sum(observed) * [1/3, 1/3, 1/3];
chi_square_stat = sum(((observed - expected).^2) ./ expected); 
df = length(observed) - 1; 
p_value = 1 - chi2cdf(chi_square_stat, df); 
alpha = 0.05; 
critical_value = chi2inv(1 - alpha, df);
fprintf('Chi-square statistic: %.2f\n', chi_square_stat); 
fprintf('Degrees of freedom: %d\n', df); 
fprintf('Critical value (0.05 significance level): %.2f\n', critical_value); fprintf('P-value: %.4f\n', p_value);


% Conclusion 
if chi_square_stat > critical_value 
 disp('Reject the null hypothesis. Observed data does not match expected  distribution.'); 
else 
 disp('Fail to reject the null hypothesis. Observed data matches the  expected distribution.'); 
end 
% Plotting the observed vs expected frequencies 
figure; 
bar(1:length(observed), [observed; expected]'); 
title('Observed vs Expected Frequencies'); 
xlabel('Categories'); 
ylabel('Frequencies'); 
legend('Observed', 'Expected');

