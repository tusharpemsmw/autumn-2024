clc;
clear;
close all;

% Initialize company's balance
company_balance = 10000;  % Initial balance in dollars

% Transaction queue (Each row: [TransactionType, Amount])
% TransactionType: 1 = Deposit, 2 = Withdrawal, 3 = Loss, 4 = Profit
transaction_queue = [
    1, 5000;  % Deposit $5000
    3, 2000;  % Loss $2000
    4, 3000;  % Profit $3000
    2, 4000;  % Withdrawal $4000
    3, 1000;  % Loss $1000
    4, 1500;  % Profit $1500
    1, 7000;  % Deposit $7000
    3, 500;   % Loss $500
    4, 2000;  % Profit $2000
    2, 3000   % Withdrawal $3000
];

% Initialize tracking variables
cumulative_profit = 0;
cumulative_loss = 0;
profit_over_time = [];
loss_over_time = [];
balance_over_time = [];

% Process transactions
disp('Processing transactions...');
for i = 1:size(transaction_queue, 1)
    transaction_type = transaction_queue(i, 1);
    amount = transaction_queue(i, 2);

    switch transaction_type
        case 1  % Deposit
            company_balance = company_balance + amount;
            disp(['Deposit: $', num2str(amount)]);
            
        case 2  % Withdrawal
            if company_balance >= amount
                company_balance = company_balance - amount;
                disp(['Withdrawal: $', num2str(amount)]);
            else
                disp(['Withdrawal failed. Insufficient balance for $', num2str(amount)]);
                continue;  % Skip to the next transaction
            end
            
        case 3  % Loss
            company_balance = company_balance - amount;
            cumulative_loss = cumulative_loss + amount;
            disp(['Loss: $', num2str(amount)]);
            
        case 4  % Profit
            company_balance = company_balance + amount;
            cumulative_profit = cumulative_profit + amount;
            disp(['Profit: $', num2str(amount)]);
            
        otherwise
            disp('Unknown transaction type. Skipping...');
            continue;
    end

    % Track metrics over time
    profit_over_time = [profit_over_time; cumulative_profit];
    loss_over_time = [loss_over_time; cumulative_loss];
    balance_over_time = [balance_over_time; company_balance];
end

% Display final results
disp('----------------------------------');
disp(['Final Company Balance: $', num2str(company_balance)]);
disp(['Total Profit: $', num2str(cumulative_profit)]);
disp(['Total Loss: $', num2str(cumulative_loss)]);

% Plot results
figure;
subplot(2, 1, 1);
plot(1:length(profit_over_time), profit_over_time, 'g', 'LineWidth', 2);
hold on;
plot(1:length(loss_over_time), loss_over_time, 'r', 'LineWidth', 2);
xlabel('Transaction Number');
ylabel('Cumulative Amount ($)');
title('Cumulative Profit and Loss Over Time');
legend('Profit', 'Loss');
grid on;

subplot(2, 1, 2);
plot(1:length(balance_over_time), balance_over_time, 'b', 'LineWidth', 2);
xlabel('Transaction Number');
ylabel('Balance ($)');
title('Company Balance Over Time');
grid on;

% Save results to file
log_file = 'transaction_summary.txt';
fileID = fopen(log_file, 'w');
fprintf(fileID, 'Transaction Summary:\n');
fprintf(fileID, 'Final Company Balance: $%d\n', company_balance);
fprintf(fileID, 'Total Profit: $%d\n', cumulative_profit);
fprintf(fileID, 'Total Loss: $%d\n', cumulative_loss);
fclose(fileID);

disp(['Transaction summary saved to ', log_file]);
