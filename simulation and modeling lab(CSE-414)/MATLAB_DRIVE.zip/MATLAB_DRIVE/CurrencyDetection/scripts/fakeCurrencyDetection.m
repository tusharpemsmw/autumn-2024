clc;
clear;
close all;

% Set paths for real and fake currency images
real_folder = 'CurrencyDetection/images/real';
fake_folder = 'CurrencyDetection/images/fake';

% Load images and labels
real_images = dir(fullfile(real_folder, '*.jpg'));  % Load real images
fake_images = dir(fullfile(fake_folder, '*.jpg')); % Load fake images

% Check if images are found in both folders
if isempty(real_images)
    error('No images found in the real folder. Check the path: %s', real_folder);
end
if isempty(fake_images)
    error('No images found in the fake folder. Check the path: %s', fake_folder);
end

% Initialize arrays to store image data and labels
num_real = length(real_images);
num_fake = length(fake_images);
num_total = num_real + num_fake;

images = zeros(128, 128, 3, num_total, 'uint8'); % Preallocate image array
labels = zeros(1, num_total);                   % Preallocate labels

% Process real images (label as 1)
count = 1;
for i = 1:num_real
    img = imread(fullfile(real_folder, real_images(i).name));
    img = imresize(img, [128, 128]);  % Resize to 128x128 pixels
    images(:, :, :, count) = img;     % Add to image data
    labels(count) = 1;                % Label real images as '1'
    count = count + 1;
end

% Process fake images (label as 0)
for i = 1:num_fake
    img = imread(fullfile(fake_folder, fake_images(i).name));
    img = imresize(img, [128, 128]);  % Resize to 128x128 pixels
    images(:, :, :, count) = img;     % Add to image data
    labels(count) = 0;                % Label fake images as '0'
    count = count + 1;
end

% Convert images to grayscale for feature extraction
gray_images = zeros(128, 128, num_total, 'uint8'); % Preallocate
for i = 1:num_total
    img = images(:, :, :, i);
    if size(img, 3) == 3
        gray_images(:, :, i) = rgb2gray(img);  % Convert to grayscale
    else
        gray_images(:, :, i) = img;  % Already grayscale
    end
end

% Feature extraction: Compute histograms of pixel intensities
features = zeros(num_total, 256); % Preallocate feature matrix
for i = 1:num_total
    hist_vals = histcounts(gray_images(:, :, i), 256);  % Histogram with 256 bins
    features(i, :) = hist_vals;  % Append to feature matrix
end

% Split data into training and testing (80% training, 20% testing)
cv = cvpartition(num_total, 'HoldOut', 0.2);  % Random split
train_features = features(cv.training, :);
train_labels = labels(cv.training);
test_features = features(cv.test, :);
test_labels = labels(cv.test);

% Train a Support Vector Machine (SVM) classifier
SVMModel = fitcsvm(train_features, train_labels, ...
                   'KernelFunction', 'linear', ...
                   'Standardize', true);

% Test the classifier
predicted_labels = predict(SVMModel, test_features);

% Evaluate the model's accuracy
accuracy = sum(predicted_labels == test_labels) / length(test_labels);
disp(['Model Accuracy: ', num2str(accuracy * 100), '%']);

% Save the trained model to the models folder
output_model_dir = 'CurrencyDetection/models';
if ~exist(output_model_dir, 'dir')
    mkdir(output_model_dir);
end
save(fullfile(output_model_dir, 'SVMModel.mat'), 'SVMModel');

% Optionally, display some test results
test_indices = find(cv.test);  % Get test indices
for i = 1:min(5, length(test_indices))  % Display up to 5 test results
    img = gray_images(:, :, test_indices(i));
    imshow(img, []);
    title(['Predicted: ', num2str(predicted_labels(i)), ', Actual: ', num2str(test_labels(i))]);
    pause(1);
end

% Save test results
output_results_dir = 'CurrencyDetection/results';
if ~exist(output_results_dir, 'dir')
    mkdir(output_results_dir);
end
output_file = fullfile(output_results_dir, 'test_results.txt');
fileID = fopen(output_file, 'w');
fprintf(fileID, 'Predicted\tActual\n');
for i = 1:length(test_labels)
    fprintf(fileID, '%d\t%d\n', predicted_labels(i), test_labels(i));
end
fclose(fileID);
disp('Test results saved to test_results.txt');
