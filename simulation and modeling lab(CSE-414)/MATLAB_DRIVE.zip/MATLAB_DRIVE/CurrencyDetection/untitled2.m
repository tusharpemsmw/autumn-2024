while true
    clc;
    disp('--- Transaction Management System ---');
    disp('1. Create Account');
    disp('2. Login');
    disp('3. Exit');
    choice = input('Choose an option: ', 's');
    
    switch choice
        case '1'
            username = input('Enter username: ', 's');
            password = input('Enter password: ', 's');
            createUser(username, password);
        case '2'
            username = input('Enter username: ', 's');
            password = input('Enter password: ', 's');
            userIndex = loginUser(username, password);
            if userIndex > 0
                while true
                    clc;
                    disp('--- User Dashboard ---');
                    disp('1. Check Balance');
                    disp('2. Deposit Money');
                    disp('3. Withdraw Money');
                    disp('4. View Transaction History');
                    disp('5. Logout');
                    userChoice = input('Choose an option: ', 's');
                    
                    switch userChoice
                        case '1'
                            checkBalance(userIndex);
                        case '2'
                            amount = input('Enter deposit amount: ');
                            depositMoney(userIndex, amount);
                        case '3'
                            amount = input('Enter withdrawal amount: ');
                            withdrawMoney(userIndex, amount);
                        case '4'
                            viewHistory(userIndex);
                        case '5'
                            disp('Logging out...');
                            break;
                        otherwise
                            disp('Invalid choice. Try again.');
                    end
                    pause(2);
                end
            end
        case '3'
            disp('Exiting system. Goodbye!');
            break;
        otherwise
            disp('Invalid choice. Try again.');
    end
end
