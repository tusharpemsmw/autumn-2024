clc;
clear;
close all;

% Simulation Parameters
sim_time = 60;             % Total simulation time in seconds
time_step = 1;             % Time step for simulation
light_cycle = [10, 3, 10]; % [Green, Yellow, Red] durations in seconds
lanes = {'North-South', 'East-West'}; % Lane directions

% Initialize Traffic Light State
light_state = 1; % 1: Green, 2: Yellow, 3: Red
current_lane = 1; % Start with North-South direction
light_timer = light_cycle(light_state); % Time left for current light state

% Visualization Setup
figure('Color', 'w');
set(gca, 'XTick', [], 'YTick', [], 'XColor', 'none', 'YColor', 'none');

% Simulation Loop
for t = 1:time_step:sim_time
    % Update traffic light timer
    light_timer = light_timer - time_step;
    
    % Check if the light needs to change
    if light_timer <= 0
        light_state = light_state + 1; % Move to the next state
        if light_state > 3
            light_state = 1; % Reset to Green
            current_lane = 3 - current_lane; % Switch to the other lane
        end
        light_timer = light_cycle(light_state); % Reset timer for new state
    end
    
    % Display Current Traffic Light State
    clf;
    hold on;
    rectangle('Position', [-1, 1, 2, 2], 'FaceColor', 'w'); % Placeholder intersection
    
    % Draw traffic lights
    % North-South Light
    if current_lane == 1
        ns_color = getLightColor(light_state);
        ew_color = 'r'; % East-West is Red
    else
        ns_color = 'r'; % North-South is Red
        ew_color = getLightColor(light_state);
    end
    
    % Traffic light rectangles
    rectangle('Position', [-0.5, 2.5, 1, 0.5], 'FaceColor', ns_color, 'EdgeColor', 'k'); % North
    rectangle('Position', [-0.5, -3, 1, 0.5], 'FaceColor', ns_color, 'EdgeColor', 'k'); % South
    rectangle('Position', [2.5, -0.5, 0.5, 1], 'FaceColor', ew_color, 'EdgeColor', 'k'); % East
    rectangle('Position', [-3, -0.5, 0.5, 1], 'FaceColor', ew_color, 'EdgeColor', 'k'); % West
    
    % Display information
    text(-2, -2.5, ['Current Lane: ', lanes{current_lane}], 'FontSize', 12);
    text(-2, -3, ['Time Left: ', num2str(light_timer), 's'], 'FontSize', 12);
    
    xlim([-3.5, 3.5]);
    ylim([-3.5, 3.5]);
    axis equal;
    pause(0.5); % Pause for visualization
end

disp('Simulation Complete.');

% Helper Function to Get Light Color
function color = getLightColor(state)
    % Return color for the light state
    switch state
        case 1
            color = 'g'; % Green
        case 2
            color = 'y'; % Yellow
        case 3
            color = 'r'; % Red
    end
end
