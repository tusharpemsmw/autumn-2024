clc;
clear;
close all;

% Initialize account database
accounts = struct();
accounts(1).ID = 101; accounts(1).Balance = 1000;
accounts(2).ID = 102; accounts(2).Balance = 2000;
accounts(3).ID = 103; accounts(3).Balance = 500;

% Transaction queue (Each row: [AccountID, Type, Amount])
% Type: 1 = Deposit, 2 = Withdrawal, 3 = Balance Inquiry
transaction_queue = [
    101, 1, 500;   % Deposit 500 into account 101
    102, 2, 1000;  % Withdraw 1000 from account 102
    103, 3, 0;     % Balance inquiry for account 103
    101, 2, 200;   % Withdraw 200 from account 101
    102, 1, 700    % Deposit 700 into account 102
];

% Transaction log
transaction_log = [];

% Process transactions
disp('Processing transactions...');
for i = 1:size(transaction_queue, 1)
    account_id = transaction_queue(i, 1);
    transaction_type = transaction_queue(i, 2);
    amount = transaction_queue(i, 3);

    % Find the account
    account_index = find([accounts.ID] == account_id, 1);
    if isempty(account_index)
        disp(['Account ', num2str(account_id), ' not found. Skipping transaction.']);
        continue;
    end
    
    % Process the transaction
    switch transaction_type
        case 1  % Deposit
            accounts(account_index).Balance = accounts(account_index).Balance + amount;
            disp(['Deposited $', num2str(amount), ' into Account ', num2str(account_id)]);
            
        case 2  % Withdrawal
            if accounts(account_index).Balance >= amount
                accounts(account_index).Balance = accounts(account_index).Balance - amount;
                disp(['Withdrew $', num2str(amount), ' from Account ', num2str(account_id)]);
            else
                disp(['Insufficient balance in Account ', num2str(account_id), '. Transaction failed.']);
            end
            
        case 3  % Balance Inquiry
            disp(['Account ', num2str(account_id), ' Balance: $', num2str(accounts(account_index).Balance)]);
    end
    
    % Log the transaction
    transaction_log = [transaction_log; account_id, transaction_type, amount];
end

% Display final account balances
disp('Final Account Balances:');
for i = 1:length(accounts)
    disp(['Account ', num2str(accounts(i).ID), ': $', num2str(accounts(i).Balance)]);
end

% Save transaction log to a file
log_file = 'transaction_log.txt';
fileID = fopen(log_file, 'w');
fprintf(fileID, 'AccountID\tType\tAmount\n');
for i = 1:size(transaction_log, 1)
    fprintf(fileID, '%d\t%d\t%d\n', transaction_log(i, :));
end
fclose(fileID);

disp(['Transaction log saved to ', log_file]);
