% Queueing System Simulation in MATLAB

% Parameters
simulationTime = 100; % Total simulation time in minutes
arrivalRate = 5; % Average number of arrivals per minute (Poisson)
serviceRate = 6; % Average service rate per minute (Exponential)

% Initialize variables
currentTime = 0; % Current simulation time
arrivalTimes = []; % Stores arrival times of customers
departureTimes = []; % Stores departure times
queueLengths = []; % Tracks queue length over time
serverBusy = false; % Server state (busy/idle)
timeNextArrival = exprnd(1/arrivalRate); % Time of next arrival
timeNextDeparture = Inf; % Time of next departure

% Simulation loop
while currentTime < simulationTime
    if timeNextArrival <= timeNextDeparture
        % Process next arrival
        currentTime = timeNextArrival;
        arrivalTimes = [arrivalTimes; currentTime];
        if ~serverBusy
            % Server starts serving immediately
            serverBusy = true;
            timeNextDeparture = currentTime + exprnd(1/serviceRate);
        else
            % Customer joins the queue
            queueLengths = [queueLengths; length(arrivalTimes) - length(departureTimes)];
        end
        % Schedule next arrival
        timeNextArrival = currentTime + exprnd(1/arrivalRate);
    else
        % Process next departure
        currentTime = timeNextDeparture;
        departureTimes = [departureTimes; currentTime];
        if length(departureTimes) < length(arrivalTimes)
            % Serve next customer in the queue
            timeNextDeparture = currentTime + exprnd(1/serviceRate);
        else
            % Queue is empty, server becomes idle
            serverBusy = false;
            timeNextDeparture = Inf;
        end
    end
end

% Results Analysis
waitingTimes = departureTimes(1:length(arrivalTimes)) - arrivalTimes; % Wait times
averageWaitingTime = mean(waitingTimes);
systemUtilization = sum(departureTimes - arrivalTimes) / simulationTime;

% Display results
fprintf('Simulation Results:\n');
fprintf('Average Waiting Time: %.2f minutes\n', averageWaitingTime);
fprintf('System Utilization: %.2f%%\n', systemUtilization * 100);

% Plot results
figure;
subplot(2, 1, 1);
histogram(waitingTimes, 'BinWidth', 0.5);
title('Histogram of Waiting Times');
xlabel('Waiting Time (minutes)');
ylabel('Frequency');
grid on;

subplot(2, 1, 2);
plot(cumsum(queueLengths));
title('Queue Length Over Time');
xlabel('Time (minutes)');
ylabel('Queue Length');
grid on;