r12 = randn(500);
disp(r12);
disp(mean(r12));
disp(std(r12));
histogram(r12);
