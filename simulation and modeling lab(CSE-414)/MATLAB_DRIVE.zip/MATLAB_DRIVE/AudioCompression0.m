% Extended Calculator with Differentiation, Integration, and Trigonometry

clc;
clear;

% Display the menu to the user
disp('Extended Calculator');
disp('--------------------');
disp('1. Arithmetic Operations');
disp('2. Differentiation');
disp('3. Integration');
disp('4. Trigonometry');
disp('5. Exit');

% Ask the user to choose an operation
operation = input('Choose an operation (1-5): ');

% Loop until the user chooses to exit
while operation ~= 5
    switch operation
        case 1
            % Arithmetic Operations
            disp('1. Addition');
            disp('2. Subtraction');
            disp('3. Multiplication');
            disp('4. Division');
            choice = input('Choose an arithmetic operation (1-4): ');

            num1 = input('Enter the first number: ');
            num2 = input('Enter the second number: ');

            switch choice
                case 1
                    result = num1 + num2;
                    fprintf('Result: %.2f\n', result);
                case 2
                    result = num1 - num2;
                    fprintf('Result: %.2f\n', result);
                case 3
                    result = num1 * num2;
                    fprintf('Result: %.2f\n', result);
                case 4
                    if num2 == 0
                        disp('Error: Division by zero is not allowed.');
                    else
                        result = num1 / num2;
                        fprintf('Result: %.2f\n', result);
                    end
                otherwise
                    disp('Invalid choice.');
            end

        case 2
            % Differentiation
            expr = input('Enter the function to differentiate (e.g., sin(x), x^2): ', 's');
            syms x;
            f = str2func(['@(x)' expr]);  % Convert string to function
            df = diff(f(x), x);
            fprintf('The derivative of the function is: %s\n', char(df));
        
        case 3
            % Integration
            expr = input('Enter the function to integrate (e.g., sin(x), x^2): ', 's');
            syms x;
            f = str2func(['@(x)' expr]);  % Convert string to function
            integral_result = int(f(x), x);
            fprintf('The integral of the function is: %s\n', char(integral_result));
        
        case 4
            % Trigonometry
            disp('1. Sine');
            disp('2. Cosine');
            disp('3. Tangent');
            disp('4. Inverse Trigonometric Functions');
            choice = input('Choose a trigonometric function (1-4): ');

            angle = input('Enter the angle in degrees: ');
            angle_rad = deg2rad(angle);  % Convert degrees to radians

            switch choice
                case 1
                    result = sin(angle_rad);
                    fprintf('sin(%.2f°) = %.2f\n', angle, result);
                case 2
                    result = cos(angle_rad);
                    fprintf('cos(%.2f°) = %.2f\n', angle, result);
                case 3
                    result = tan(angle_rad);
                    fprintf('tan(%.2f°) = %.2f\n', angle, result);
                case 4
                    disp('Inverse Trigonometric Functions:');
                    disp('1. arcsin');
                    disp('2. arccos');
                    disp('3. arctan');
                    inverse_choice = input('Choose the inverse trigonometric function (1-3): ');
                    
                    switch inverse_choice
                        case 1
                            result = asin(sin(angle_rad));
                            fprintf('arcsin(%.2f°) = %.2f radians\n', angle, result);
                        case 2
                            result = acos(cos(angle_rad));
                            fprintf('arccos(%.2f°) = %.2f radians\n', angle, result);
                        case 3
                            result = atan(tan(angle_rad));
                            fprintf('arctan(%.2f°) = %.2f radians\n', angle, result);
                        otherwise
                            disp('Invalid choice.');
                    end
                otherwise
                    disp('Invalid choice.');
            end

        otherwise
            disp('Invalid option! Please try again.');
    end
    
    % Display the menu again
    disp(' ');
    disp('Choose another operation or press 5 to exit.');
    disp('1. Arithmetic Operations');
    disp('2. Differentiation');
    disp('3. Integration');
    disp('4. Trigonometry');
    disp('5. Exit');
    
    % Ask the user to choose an operation again
    operation = input('Choose an operation (1-5): ');
end

disp('Thank you for using the extended calculator!');
