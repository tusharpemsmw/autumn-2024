x=[30,20,10,40]
pie(x)
title("pie Chart")