r9 = rand (1,10);
disp(r9);
r10 = rand(4,4);
disp(r10);
histogram(r9);