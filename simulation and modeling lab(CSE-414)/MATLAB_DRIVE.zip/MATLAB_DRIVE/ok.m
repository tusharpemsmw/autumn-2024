x=10:10
y1=x.^2
y2=x.^3
plot(y1,y2)

title("plot Wave")
xlabel("x")
xlabel("y")
