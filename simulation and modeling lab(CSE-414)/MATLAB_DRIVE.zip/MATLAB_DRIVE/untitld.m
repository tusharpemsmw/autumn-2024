% Human Disease Detection (Chest X-ray) in MATLAB

clc;
clear;
close all;

% Step 1: Load the Medical Image
[file, path] = uigetfile({'*.jpg;*.png;*.dcm', 'Image Files'}, 'Select a Medical Image');
if isequal(file, 0)
    disp('No image selected. Exiting...');
    return;
end
img = imread(fullfile(path, file));
if ndims(img) == 3
    img = rgb2gray(img); % Convert to grayscale if the image is RGB
end
figure, imshow(img), title('Original Image');

% Step 2: Preprocessing
% Resize image for consistency
img = imresize(img, [256 256]);

% Enhance contrast
enhancedImg = imadjust(img);
figure, imshow(enhancedImg), title('Enhanced Contrast Image');

% Step 3: Segmentation (e.g., lung region extraction)
% Apply adaptive thresholding
threshold = adaptthresh(enhancedImg, 0.6);
binaryImg = imbinarize(enhancedImg, threshold);
binaryImg = imfill(binaryImg, 'holes'); % Fill holes
figure, imshow(binaryImg), title('Segmented Lungs');

% Step 4: Feature Extraction
% Extract statistical features from the lung region
stats = regionprops(binaryImg, enhancedImg, 'MeanIntensity', 'Area', 'Eccentricity');
if isempty(stats)
    disp('No significant regions detected. Exiting...');
    return;
end

% Extracting key features
meanIntensity = stats(1).MeanIntensity;
lungArea = stats(1).Area;
eccentricity = stats(1).Eccentricity;

disp('Extracted Features:');
disp(['Mean Intensity: ', num2str(meanIntensity)]);
disp(['Lung Area: ', num2str(lungArea)]);
disp(['Eccentricity: ', num2str(eccentricity)]);

% Step 5: Classification (Rule-based example)
% Define thresholds for a simple classification (replace with ML/DL model for better accuracy)
if meanIntensity < 100 && lungArea > 30000 && eccentricity > 0.6
    disp('Disease Detected: Possible Pneumonia');
else
    disp('No Disease Detected');
end

% Step 6: Visualization
% Overlay detected region on the original image
labeledImg = bwlabel(binaryImg);
rgbLabeledImg = label2rgb(labeledImg, 'jet', 'k', 'shuffle');
figure, imshowpair(img, rgbLabeledImg, 'montage'), title('Original and Detected Regions');
  