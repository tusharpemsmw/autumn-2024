% Load sample data (for example, students' grades)
load examgrades;
test1 = grades(:,1);  % First column of exam grades
% Center and scale the data for testing against a standard normal distribution
x = (test1 - 75) / 10;
% Perform the one-sample Kolmogorov-Smirnov test
h = kstest(x);  % Test against standard normal distribution (mean 0, std 1)

% Check the result
if h == 0
    disp('Fail to reject the null hypothesis: Data follows a normal distribution.');
else
    disp('Reject the null hypothesis: Data does not follow a normal distribution.');
end
% Plot the empirical CDF
[f,x_values] = ecdf(x);  % Empirical CDF
figure;
F = plot(x_values, f, 'LineWidth', 2); 
hold on;

% Plot the theoretical CDF for standard normal distribution
G = plot(x_values, normcdf(x_values, 0, 1), 'r-', 'LineWidth', 2);

% Add legend and labels
legend([F G], 'Empirical CDF', 'Standard Normal CDF', 'Location', 'SE');
title('Empirical vs. Theoretical CDF');
xlabel('Test Scores (Normalized)');
ylabel('CDF');
