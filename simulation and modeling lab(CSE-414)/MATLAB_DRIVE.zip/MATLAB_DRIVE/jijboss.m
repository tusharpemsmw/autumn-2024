% Parameters
S0 = 100; % Initial stock price
mu = 0.05; % Expected return (drift)
sigma = 0.2; % Volatility
T = 1; % Time horizon (in years)
dt = 1/252; % Time step (daily steps, 252 trading days in a year)
N = T / dt; % Number of time steps
num_simulations = 10; % Number of simulated price paths

% Social Influence Parameters
alpha = 0.02; % Strength of social influence (adjustable)
sentiment_amplitude = 0.05; % Max sentiment value
sentiment_frequency = 10; % Frequency of sentiment changes

% Preallocate for efficiency
stock_prices = zeros(num_simulations, N + 1);
sentiments = zeros(1, N); % Store sentiment values for analysis

% Generate sentiment over time
for t = 1:N
% Example: Randomly varying sentiment with periodic behavior
sentiments(t) = sentiment_amplitude * sin(2 * pi * t / sentiment_frequency) + ...
0.01 * randn; % Add random noise to sentiment
end

% Simulate Stock Price Paths
for sim = 1:num_simulations
stock_prices(sim, 1) = S0;
for t = 2:N+1
% Brownian motion increment
dW = sqrt(dt) * randn;
% Social influence term
sentiment_t = sentiments(t-1); % Use sentiment at time t-1
% Modified GBM equation
stock_prices(sim, t) = stock_prices(sim, t-1) * ...
exp((mu - 0.5 * sigma^2) * dt + sigma * dW + alpha * sentiment_t);
end
end

% Plot Simulated Paths
time = 0:dt:T;
figure;
subplot(2, 1, 1);
plot(time, stock_prices', 'LineWidth', 1.2);
title('Simulated Stock Price Paths with Social Influence');
xlabel('Time (Years)');
ylabel('Stock Price');
grid on;

% Plot Sentiment Over Time
subplot(2, 1, 2);
plot(time(1:end-1), sentiments, 'r', 'LineWidth', 1.2);
title('Sentiment Over Time');
xlabel('Time (Years)');
ylabel('Sentiment Value');
grid on;

% Statistical Analysis
final_prices = stock_prices(:, end);
mean_price = mean(final_prices);
std_price = std(final_prices);

disp(['Expected Final Price: ', num2str(mean_price)]);
disp(['Standard Deviation of Final Prices: ', num2str(std_price)]);